from socket import timeout


timeout = 120